package com.mbautista.project_i.controller;

import com.mbautista.project_i.Main;
import com.mbautista.project_i.helper.JDBC;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLOutput;
import java.sql.Statement;

public class Login {
    @FXML
    public TextField text_username;
    @FXML
    public PasswordField text_password;
    @FXML
    public Label label_errorLogIn;
    Stage stage;

    public void  onClickSignIn (ActionEvent actionEvent) {
        System.out.println("onClickSignIn");

        String username = text_username.getText();
        String password = text_password.getText();

        System.out.println(username);
        System.out.println(password);

        if (username.isBlank() == false && password.isBlank() == false) {
            validate();

        } else {

            label_errorLogIn.setText("Enter Username and password");

            System.out.println("enter user and password");
        }
    }
    public void validate(){

        JDBC connectNow = new JDBC();
        Connection connectDB = connectNow.openConnection();

        String verifyLogin = "SELECT count(1) FROM client_schedule.users where User_Name = '"+ text_username.getText()+"' AND Password ='"+ text_password.getText() +"'";
        try{
          Statement statement = connectDB.createStatement();
          ResultSet queryResult = statement.executeQuery(verifyLogin);
          while(queryResult.next()){
             if(queryResult.getInt(1)==1){
             System.out.println("it is validated");
             label_errorLogIn.setText("");
//             FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/com/mbautista/project_i/Menu.fxml"));
                 FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/project_i/Menu.fxml"));

                 Scene scene = new Scene(fxmlLoader.load(), 540, 540);
            stage.setTitle("log in!");
            stage.setScene(scene);
            stage.show();
             }else{
             label_errorLogIn.setText("Username or password is wrong or it does not exist");
             System.out.println("it is not valid try again");
         }
          }
        }catch(Exception e){
        e.printStackTrace();
      }
        }

//    private void clickAndVal(Stage stage) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Menu.fxml"));
//        Scene scene = new Scene(fxmlLoader.load(), 540, 540);
//        stage.setTitle("log in!");
//        stage.setScene(scene);
//        stage.show();
//    }




}



