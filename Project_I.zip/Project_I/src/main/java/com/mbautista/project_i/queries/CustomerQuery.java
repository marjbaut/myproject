package com.mbautista.project_i.queries;

public class CustomerQuery {
}
