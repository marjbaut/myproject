module com.mbautista.project_i {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.mbautista.project_i to javafx.fxml;
    exports com.mbautista.project_i;
    exports com.mbautista.project_i.controller;
}